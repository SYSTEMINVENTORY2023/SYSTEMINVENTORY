<html>
<head>
<title>Actualizar</title>
<head> <link href='public/css/formulario1.css' rel='stylesheet' type='text/css' />
	
</head>
<body>
 <h1>BIENVENIDO A TELCOMUNDO</h1>
    
    <form action='actualizar.php' method="POST">
       <h3> Ingrese id de usuario </h3> 
        <input type="number"name="codigo">
        <br>
        <input type="submit"value="buscar ">
    </form>
</body>
</html>
